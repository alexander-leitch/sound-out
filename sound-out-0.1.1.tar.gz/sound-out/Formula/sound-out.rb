class SoundOut < Formula
  desc "A macOS tool to change audio output source of applications"
  homepage "https://github.com/alexander-leitch/sound-out"
  url "https://github.com/alexander-leitch/sound-out/archive/refs/tags/v0.1.1.tar.gz"
  sha256 ""
  license "MIT"
  head "https://github.com/alexander-leitch/sound-out.git", branch: "main"

  depends_on "rust" => :build
  depends_on "switchaudio-osx"

  def install
    system "cargo", "install", "--locked", "--root", prefix, "--path", "."
  end

  test do
    system "#{bin}/sound-out", "--help"
    system "#{bin}/sound-out", "list-devices"
  end
end